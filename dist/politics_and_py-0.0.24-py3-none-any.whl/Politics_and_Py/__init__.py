from .Core import *
from .Config import key, _Key