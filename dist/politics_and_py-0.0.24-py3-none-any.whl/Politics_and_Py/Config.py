_Key = ""
_Request_Res = "money, coal, oil, uranium, iron, bauxite, lead, gasoline, munitions, steel, aluminum, food"


def key(_):
    """Used to define the api key to be used"""
    global _Key
    _Key = _
