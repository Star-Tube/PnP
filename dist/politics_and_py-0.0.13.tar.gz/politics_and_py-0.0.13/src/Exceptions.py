class InvalidRequest(Exception):
    pass


class WrongID(Exception):
    pass


class NoID(Exception):
    pass
